﻿namespace inventory_system
{
    partial class @return
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.return_text_description = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.return_text_type = new System.Windows.Forms.TextBox();
            this.labelassettype = new System.Windows.Forms.Label();
            this.searachasset = new System.Windows.Forms.Button();
            this.return_text_name = new System.Windows.Forms.TextBox();
            this.labelassetname = new System.Windows.Forms.Label();
            this.return_text_id = new System.Windows.Forms.TextBox();
            this.labelAssetid = new System.Windows.Forms.Label();
            this.updateasset = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.assetstatus = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.asetserial = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // return_text_description
            // 
            this.return_text_description.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.return_text_description.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.return_text_description.Location = new System.Drawing.Point(323, 271);
            this.return_text_description.Name = "return_text_description";
            this.return_text_description.Size = new System.Drawing.Size(198, 30);
            this.return_text_description.TabIndex = 29;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(96, 271);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(168, 25);
            this.label1.TabIndex = 28;
            this.label1.Text = "Description";
            // 
            // return_text_type
            // 
            this.return_text_type.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.return_text_type.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.return_text_type.Location = new System.Drawing.Point(323, 224);
            this.return_text_type.Name = "return_text_type";
            this.return_text_type.Size = new System.Drawing.Size(198, 30);
            this.return_text_type.TabIndex = 25;
            // 
            // labelassettype
            // 
            this.labelassettype.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.labelassettype.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelassettype.Location = new System.Drawing.Point(96, 227);
            this.labelassettype.Name = "labelassettype";
            this.labelassettype.Size = new System.Drawing.Size(168, 25);
            this.labelassettype.TabIndex = 24;
            this.labelassettype.Text = "Asset Type\r\n";
            // 
            // searachasset
            // 
            this.searachasset.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.searachasset.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searachasset.Location = new System.Drawing.Point(323, 424);
            this.searachasset.Name = "searachasset";
            this.searachasset.Size = new System.Drawing.Size(161, 37);
            this.searachasset.TabIndex = 23;
            this.searachasset.Text = "Search Asset";
            this.searachasset.UseVisualStyleBackColor = false;
            // 
            // return_text_name
            // 
            this.return_text_name.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.return_text_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.return_text_name.Location = new System.Drawing.Point(323, 182);
            this.return_text_name.Name = "return_text_name";
            this.return_text_name.Size = new System.Drawing.Size(198, 30);
            this.return_text_name.TabIndex = 22;
            // 
            // labelassetname
            // 
            this.labelassetname.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.labelassetname.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelassetname.Location = new System.Drawing.Point(96, 187);
            this.labelassetname.Name = "labelassetname";
            this.labelassetname.Size = new System.Drawing.Size(168, 25);
            this.labelassetname.TabIndex = 21;
            this.labelassetname.Text = "Asset Name";
            // 
            // return_text_id
            // 
            this.return_text_id.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.return_text_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.return_text_id.Location = new System.Drawing.Point(323, 133);
            this.return_text_id.Name = "return_text_id";
            this.return_text_id.Size = new System.Drawing.Size(198, 30);
            this.return_text_id.TabIndex = 20;
            // 
            // labelAssetid
            // 
            this.labelAssetid.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.labelAssetid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAssetid.Location = new System.Drawing.Point(96, 136);
            this.labelAssetid.Name = "labelAssetid";
            this.labelAssetid.Size = new System.Drawing.Size(168, 25);
            this.labelAssetid.TabIndex = 19;
            this.labelAssetid.Text = "Asset ID";
            // 
            // updateasset
            // 
            this.updateasset.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.updateasset.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateasset.Location = new System.Drawing.Point(91, 424);
            this.updateasset.Name = "updateasset";
            this.updateasset.Size = new System.Drawing.Size(161, 37);
            this.updateasset.TabIndex = 18;
            this.updateasset.Text = "Update Asset";
            this.updateasset.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(91, 312);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(173, 37);
            this.button3.TabIndex = 30;
            this.button3.Text = "Asset Status";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // assetstatus
            // 
            this.assetstatus.FormattingEnabled = true;
            this.assetstatus.Location = new System.Drawing.Point(323, 327);
            this.assetstatus.Name = "assetstatus";
            this.assetstatus.Size = new System.Drawing.Size(198, 21);
            this.assetstatus.TabIndex = 31;
            this.assetstatus.SelectedIndexChanged += new System.EventHandler(this.assetstatus_SelectedIndexChanged);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(573, 327);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(161, 37);
            this.button1.TabIndex = 32;
            this.button1.Text = "Get Details";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // asetserial
            // 
            this.asetserial.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.asetserial.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.asetserial.Location = new System.Drawing.Point(323, 82);
            this.asetserial.Name = "asetserial";
            this.asetserial.Size = new System.Drawing.Size(198, 30);
            this.asetserial.TabIndex = 34;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(96, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(168, 25);
            this.label2.TabIndex = 33;
            this.label2.Text = "Search By Serial";
            // 
            // @return
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(972, 509);
            this.Controls.Add(this.asetserial);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.assetstatus);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.return_text_description);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.return_text_type);
            this.Controls.Add(this.labelassettype);
            this.Controls.Add(this.searachasset);
            this.Controls.Add(this.return_text_name);
            this.Controls.Add(this.labelassetname);
            this.Controls.Add(this.return_text_id);
            this.Controls.Add(this.labelAssetid);
            this.Controls.Add(this.updateasset);
            this.Name = "@return";
            this.Text = "@return";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox return_text_description;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox return_text_type;
        private System.Windows.Forms.Label labelassettype;
        private System.Windows.Forms.Button searachasset;
        private System.Windows.Forms.TextBox return_text_name;
        private System.Windows.Forms.Label labelassetname;
        private System.Windows.Forms.TextBox return_text_id;
        private System.Windows.Forms.Label labelAssetid;
        private System.Windows.Forms.Button updateasset;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ComboBox assetstatus;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox asetserial;
        private System.Windows.Forms.Label label2;
    }
}