﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace inventory_system
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           // labelname.Text = textBoxadminname.Text;
            //labeladminpassqord.Text = textBoxadminpass.Text;
            string dbconn1 = users.dbconn();
            MySqlConnection con = new MySqlConnection(dbconn1);
            con.Open();
          //  if (con.State == ConnectionState.Open)
            //{
              //  MessageBox.Show("Connected");
            //}
            //else
            //{
             //   MessageBox.Show("Not Connected");
            //}
            this.Hide();
            //users u = new users();
            //u.Show();
          
           // Asset_id a = new Asset_id();
            //a.Show();
            //@return r = new @return();
            //r.Show();
            main m = new main();
            m.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBoxadminname.Clear();
            textBoxadminpass.Clear();
        }

        private void textBoxadminpass_TextChanged(object sender, EventArgs e)
        {

        }

        private void labeladminpassqord_Click(object sender, EventArgs e)
        {

        }

        private void textBoxadminname_TextChanged(object sender, EventArgs e)
        {

        }

        private void labelname_Click(object sender, EventArgs e)
        {

        }
    }
}
