﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace inventory_system
{
    public partial class Report : Form
    {
        public Report()
        {
            InitializeComponent();
        }

        private void labeladminpassqord_Click(object sender, EventArgs e)
        {

        }
        
        private void addinvoice_Click(object sender, EventArgs e)
        {
            
        }

        private void updateinvoice_Click(object sender, EventArgs e)
        {

        }
    }
}
