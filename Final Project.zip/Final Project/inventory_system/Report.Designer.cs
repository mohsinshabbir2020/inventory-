﻿namespace inventory_system
{
    partial class Report
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dateTimePickerinvoice = new System.Windows.Forms.DateTimePicker();
            this.searchinvoice = new System.Windows.Forms.Button();
            this.deleteinvoice = new System.Windows.Forms.Button();
            this.updateinvoice = new System.Windows.Forms.Button();
            this.labelassetname = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.GridViewreport = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.GridViewreport)).BeginInit();
            this.SuspendLayout();
            // 
            // dateTimePickerinvoice
            // 
            this.dateTimePickerinvoice.Location = new System.Drawing.Point(220, 27);
            this.dateTimePickerinvoice.Name = "dateTimePickerinvoice";
            this.dateTimePickerinvoice.Size = new System.Drawing.Size(200, 20);
            this.dateTimePickerinvoice.TabIndex = 50;
            // 
            // searchinvoice
            // 
            this.searchinvoice.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.searchinvoice.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchinvoice.Location = new System.Drawing.Point(192, 392);
            this.searchinvoice.Name = "searchinvoice";
            this.searchinvoice.Size = new System.Drawing.Size(944, 37);
            this.searchinvoice.TabIndex = 47;
            this.searchinvoice.Text = "Search Reports";
            this.searchinvoice.UseVisualStyleBackColor = false;
            // 
            // deleteinvoice
            // 
            this.deleteinvoice.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.deleteinvoice.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteinvoice.Location = new System.Drawing.Point(12, 166);
            this.deleteinvoice.Name = "deleteinvoice";
            this.deleteinvoice.Size = new System.Drawing.Size(174, 37);
            this.deleteinvoice.TabIndex = 46;
            this.deleteinvoice.Text = "Department Wise";
            this.deleteinvoice.UseVisualStyleBackColor = false;
            // 
            // updateinvoice
            // 
            this.updateinvoice.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.updateinvoice.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateinvoice.Location = new System.Drawing.Point(12, 123);
            this.updateinvoice.Name = "updateinvoice";
            this.updateinvoice.Size = new System.Drawing.Size(174, 37);
            this.updateinvoice.TabIndex = 44;
            this.updateinvoice.Text = "PO Wise";
            this.updateinvoice.UseVisualStyleBackColor = false;
            this.updateinvoice.Click += new System.EventHandler(this.updateinvoice_Click);
            // 
            // labelassetname
            // 
            this.labelassetname.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.labelassetname.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelassetname.Location = new System.Drawing.Point(12, 22);
            this.labelassetname.Name = "labelassetname";
            this.labelassetname.Size = new System.Drawing.Size(184, 25);
            this.labelassetname.TabIndex = 42;
            this.labelassetname.Text = "Date";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(12, 80);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(174, 37);
            this.button1.TabIndex = 51;
            this.button1.Text = "Asset Wise";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // GridViewreport
            // 
            this.GridViewreport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridViewreport.Location = new System.Drawing.Point(192, 65);
            this.GridViewreport.Name = "GridViewreport";
            this.GridViewreport.Size = new System.Drawing.Size(1094, 286);
            this.GridViewreport.TabIndex = 52;
            // 
            // Report
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(998, 556);
            this.Controls.Add(this.GridViewreport);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dateTimePickerinvoice);
            this.Controls.Add(this.searchinvoice);
            this.Controls.Add(this.deleteinvoice);
            this.Controls.Add(this.updateinvoice);
            this.Controls.Add(this.labelassetname);
            this.Name = "Report";
            this.Text = "Report";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.GridViewreport)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dateTimePickerinvoice;
        private System.Windows.Forms.Button searchinvoice;
        private System.Windows.Forms.Button deleteinvoice;
        private System.Windows.Forms.Button updateinvoice;
        private System.Windows.Forms.Label labelassetname;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView GridViewreport;

    }
}