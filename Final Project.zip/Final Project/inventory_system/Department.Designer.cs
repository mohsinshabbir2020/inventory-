﻿namespace inventory_system
{
    partial class Department
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.deleteasset = new System.Windows.Forms.Button();
            this.textBoxassettype = new System.Windows.Forms.TextBox();
            this.labelassettype = new System.Windows.Forms.Label();
            this.textBoxassetname = new System.Windows.Forms.TextBox();
            this.labelassetname = new System.Windows.Forms.Label();
            this.textBoxassetid = new System.Windows.Forms.TextBox();
            this.labelAssetid = new System.Windows.Forms.Label();
            this.GridViewdepartment = new System.Windows.Forms.DataGridView();
            this.updateasset = new System.Windows.Forms.Button();
            this.addasset = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.GridViewdepartment)).BeginInit();
            this.SuspendLayout();
            // 
            // deleteasset
            // 
            this.deleteasset.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.deleteasset.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteasset.Location = new System.Drawing.Point(265, 253);
            this.deleteasset.Name = "deleteasset";
            this.deleteasset.Size = new System.Drawing.Size(233, 37);
            this.deleteasset.TabIndex = 24;
            this.deleteasset.Text = "Update";
            this.deleteasset.UseVisualStyleBackColor = false;
            // 
            // textBoxassettype
            // 
            this.textBoxassettype.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxassettype.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxassettype.Location = new System.Drawing.Point(265, 142);
            this.textBoxassettype.Name = "textBoxassettype";
            this.textBoxassettype.Size = new System.Drawing.Size(198, 30);
            this.textBoxassettype.TabIndex = 23;
            // 
            // labelassettype
            // 
            this.labelassettype.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.labelassettype.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelassettype.Location = new System.Drawing.Point(10, 144);
            this.labelassettype.Name = "labelassettype";
            this.labelassettype.Size = new System.Drawing.Size(216, 25);
            this.labelassettype.TabIndex = 22;
            this.labelassettype.Text = "Department Description";
            // 
            // textBoxassetname
            // 
            this.textBoxassetname.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxassetname.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxassetname.Location = new System.Drawing.Point(265, 100);
            this.textBoxassetname.Name = "textBoxassetname";
            this.textBoxassetname.Size = new System.Drawing.Size(198, 30);
            this.textBoxassetname.TabIndex = 20;
            // 
            // labelassetname
            // 
            this.labelassetname.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.labelassetname.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelassetname.Location = new System.Drawing.Point(12, 56);
            this.labelassetname.Name = "labelassetname";
            this.labelassetname.Size = new System.Drawing.Size(214, 25);
            this.labelassetname.TabIndex = 19;
            this.labelassetname.Text = "Department ID";
            // 
            // textBoxassetid
            // 
            this.textBoxassetid.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxassetid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxassetid.Location = new System.Drawing.Point(265, 51);
            this.textBoxassetid.Name = "textBoxassetid";
            this.textBoxassetid.Size = new System.Drawing.Size(198, 30);
            this.textBoxassetid.TabIndex = 18;
            // 
            // labelAssetid
            // 
            this.labelAssetid.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.labelAssetid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAssetid.Location = new System.Drawing.Point(12, 100);
            this.labelAssetid.Name = "labelAssetid";
            this.labelAssetid.Size = new System.Drawing.Size(214, 25);
            this.labelAssetid.TabIndex = 17;
            this.labelAssetid.Text = "Department Name";
            // 
            // GridViewdepartment
            // 
            this.GridViewdepartment.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridViewdepartment.Location = new System.Drawing.Point(512, 51);
            this.GridViewdepartment.Name = "GridViewdepartment";
            this.GridViewdepartment.Size = new System.Drawing.Size(798, 297);
            this.GridViewdepartment.TabIndex = 28;
            // 
            // updateasset
            // 
            this.updateasset.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.updateasset.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateasset.Location = new System.Drawing.Point(17, 311);
            this.updateasset.Name = "updateasset";
            this.updateasset.Size = new System.Drawing.Size(481, 37);
            this.updateasset.TabIndex = 21;
            this.updateasset.Text = "Delete";
            this.updateasset.UseVisualStyleBackColor = false;
            // 
            // addasset
            // 
            this.addasset.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.addasset.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addasset.Location = new System.Drawing.Point(12, 253);
            this.addasset.Name = "addasset";
            this.addasset.Size = new System.Drawing.Size(233, 37);
            this.addasset.TabIndex = 16;
            this.addasset.Text = "Add";
            this.addasset.UseVisualStyleBackColor = false;
            // 
            // Department
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1041, 494);
            this.Controls.Add(this.GridViewdepartment);
            this.Controls.Add(this.deleteasset);
            this.Controls.Add(this.textBoxassettype);
            this.Controls.Add(this.labelassettype);
            this.Controls.Add(this.updateasset);
            this.Controls.Add(this.textBoxassetname);
            this.Controls.Add(this.labelassetname);
            this.Controls.Add(this.textBoxassetid);
            this.Controls.Add(this.labelAssetid);
            this.Controls.Add(this.addasset);
            this.Name = "Department";
            this.Text = "Department Name";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.GridViewdepartment)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button deleteasset;
        private System.Windows.Forms.TextBox textBoxassettype;
        private System.Windows.Forms.Label labelassettype;
        private System.Windows.Forms.TextBox textBoxassetname;
        private System.Windows.Forms.Label labelassetname;
        private System.Windows.Forms.TextBox textBoxassetid;
        private System.Windows.Forms.Label labelAssetid;
        private System.Windows.Forms.DataGridView GridViewdepartment;
        private System.Windows.Forms.Button updateasset;
        private System.Windows.Forms.Button addasset;

    }
}