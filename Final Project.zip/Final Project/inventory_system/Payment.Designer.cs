﻿namespace inventory_system
{
    partial class Payment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.searchinvoice = new System.Windows.Forms.Button();
            this.deleteinvoice = new System.Windows.Forms.Button();
            this.labelassettype = new System.Windows.Forms.Label();
            this.updateinvoice = new System.Windows.Forms.Button();
            this.textBoxitemname = new System.Windows.Forms.TextBox();
            this.labelassetname = new System.Windows.Forms.Label();
            this.textBoxinvoicenumber = new System.Windows.Forms.TextBox();
            this.labelAssetid = new System.Windows.Forms.Label();
            this.addinvoice = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxinnvoicedescription = new System.Windows.Forms.TextBox();
            this.dateTimePickerinvoice = new System.Windows.Forms.DateTimePicker();
            this.GridViewpo = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.GridViewpo)).BeginInit();
            this.SuspendLayout();
            // 
            // searchinvoice
            // 
            this.searchinvoice.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.searchinvoice.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchinvoice.Location = new System.Drawing.Point(652, 400);
            this.searchinvoice.Name = "searchinvoice";
            this.searchinvoice.Size = new System.Drawing.Size(161, 37);
            this.searchinvoice.TabIndex = 35;
            this.searchinvoice.Text = "Search invoice";
            this.searchinvoice.UseVisualStyleBackColor = false;
            // 
            // deleteinvoice
            // 
            this.deleteinvoice.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.deleteinvoice.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteinvoice.Location = new System.Drawing.Point(449, 400);
            this.deleteinvoice.Name = "deleteinvoice";
            this.deleteinvoice.Size = new System.Drawing.Size(161, 37);
            this.deleteinvoice.TabIndex = 34;
            this.deleteinvoice.Text = "Delete Innvoice";
            this.deleteinvoice.UseVisualStyleBackColor = false;
            // 
            // labelassettype
            // 
            this.labelassettype.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.labelassettype.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelassettype.Location = new System.Drawing.Point(26, 129);
            this.labelassettype.Name = "labelassettype";
            this.labelassettype.Size = new System.Drawing.Size(184, 25);
            this.labelassettype.TabIndex = 32;
            this.labelassettype.Text = "Item Name";
            // 
            // updateinvoice
            // 
            this.updateinvoice.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.updateinvoice.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateinvoice.Location = new System.Drawing.Point(242, 400);
            this.updateinvoice.Name = "updateinvoice";
            this.updateinvoice.Size = new System.Drawing.Size(161, 37);
            this.updateinvoice.TabIndex = 31;
            this.updateinvoice.Text = "Update Invoice";
            this.updateinvoice.UseVisualStyleBackColor = false;
            // 
            // textBoxitemname
            // 
            this.textBoxitemname.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxitemname.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxitemname.Location = new System.Drawing.Point(253, 124);
            this.textBoxitemname.Name = "textBoxitemname";
            this.textBoxitemname.Size = new System.Drawing.Size(198, 30);
            this.textBoxitemname.TabIndex = 30;
            // 
            // labelassetname
            // 
            this.labelassetname.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.labelassetname.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelassetname.Location = new System.Drawing.Point(26, 171);
            this.labelassetname.Name = "labelassetname";
            this.labelassetname.Size = new System.Drawing.Size(184, 25);
            this.labelassetname.TabIndex = 29;
            this.labelassetname.Text = "Date";
            // 
            // textBoxinvoicenumber
            // 
            this.textBoxinvoicenumber.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxinvoicenumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxinvoicenumber.Location = new System.Drawing.Point(253, 75);
            this.textBoxinvoicenumber.Name = "textBoxinvoicenumber";
            this.textBoxinvoicenumber.Size = new System.Drawing.Size(198, 30);
            this.textBoxinvoicenumber.TabIndex = 28;
            // 
            // labelAssetid
            // 
            this.labelAssetid.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.labelAssetid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAssetid.Location = new System.Drawing.Point(26, 78);
            this.labelAssetid.Name = "labelAssetid";
            this.labelAssetid.Size = new System.Drawing.Size(184, 25);
            this.labelAssetid.TabIndex = 27;
            this.labelAssetid.Text = "Invoice Number";
            // 
            // addinvoice
            // 
            this.addinvoice.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.addinvoice.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addinvoice.Location = new System.Drawing.Point(22, 400);
            this.addinvoice.Name = "addinvoice";
            this.addinvoice.Size = new System.Drawing.Size(161, 37);
            this.addinvoice.TabIndex = 26;
            this.addinvoice.Text = "Add Innvoice";
            this.addinvoice.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(26, 216);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(184, 25);
            this.label1.TabIndex = 36;
            this.label1.Text = "Invoice Description";
            // 
            // textBoxinnvoicedescription
            // 
            this.textBoxinnvoicedescription.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxinnvoicedescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxinnvoicedescription.Location = new System.Drawing.Point(253, 211);
            this.textBoxinnvoicedescription.Name = "textBoxinnvoicedescription";
            this.textBoxinnvoicedescription.Size = new System.Drawing.Size(198, 30);
            this.textBoxinnvoicedescription.TabIndex = 37;
            // 
            // dateTimePickerinvoice
            // 
            this.dateTimePickerinvoice.Location = new System.Drawing.Point(253, 171);
            this.dateTimePickerinvoice.Name = "dateTimePickerinvoice";
            this.dateTimePickerinvoice.Size = new System.Drawing.Size(200, 20);
            this.dateTimePickerinvoice.TabIndex = 38;
            // 
            // GridViewpo
            // 
            this.GridViewpo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridViewpo.Location = new System.Drawing.Point(484, 48);
            this.GridViewpo.Name = "GridViewpo";
            this.GridViewpo.Size = new System.Drawing.Size(793, 233);
            this.GridViewpo.TabIndex = 39;
            // 
            // Payment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(966, 498);
            this.Controls.Add(this.GridViewpo);
            this.Controls.Add(this.dateTimePickerinvoice);
            this.Controls.Add(this.textBoxinnvoicedescription);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.searchinvoice);
            this.Controls.Add(this.deleteinvoice);
            this.Controls.Add(this.labelassettype);
            this.Controls.Add(this.updateinvoice);
            this.Controls.Add(this.textBoxitemname);
            this.Controls.Add(this.labelassetname);
            this.Controls.Add(this.textBoxinvoicenumber);
            this.Controls.Add(this.labelAssetid);
            this.Controls.Add(this.addinvoice);
            this.Name = "Payment";
            this.Text = "Payment";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.GridViewpo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button searchinvoice;
        private System.Windows.Forms.Button deleteinvoice;
        private System.Windows.Forms.Label labelassettype;
        private System.Windows.Forms.Button updateinvoice;
        private System.Windows.Forms.TextBox textBoxitemname;
        private System.Windows.Forms.Label labelassetname;
        private System.Windows.Forms.TextBox textBoxinvoicenumber;
        private System.Windows.Forms.Label labelAssetid;
        private System.Windows.Forms.Button addinvoice;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxinnvoicedescription;
        private System.Windows.Forms.DateTimePicker dateTimePickerinvoice;
        private System.Windows.Forms.DataGridView GridViewpo;
    }
}