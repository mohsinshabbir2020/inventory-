﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace inventory_system.classes
{
    class report
    {
        protected DateTime date;


        public DateTime Date
        { set { date = value; } get { return date; } }
        //all will be drive data from different forms

    }
}
