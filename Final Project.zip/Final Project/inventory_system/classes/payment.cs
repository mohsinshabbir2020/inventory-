﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace inventory_system.classes
{
    class payment
    {
        protected DateTime date;
        protected int invoicenumber;
        protected string description;


        public DateTime Date
        { set { date = value; } get { return date; } }

        public int Invoicenumber
        { set { invoicenumber = value; } get { return invoicenumber; } }

        public string Description
        { set { description = value; } get { return description; } }

    }
}
