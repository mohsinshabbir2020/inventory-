﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace inventory_system.classes
{
    class department
    {
        protected string name;
        protected string description;


        public string Name
        { set { name = value; } get { return name; } }

        public string Description
        { set { description = value; } get { return description; } }
    }
}
