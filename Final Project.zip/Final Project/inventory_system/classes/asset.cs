﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace inventory_system.classes
{
    class asset
    {
        protected DateTime date;
        protected int id;
        protected string description;
        protected string type;


        public DateTime Date
        { set { date = value; } get { return date; } }

        public int Id
        { set { id = value; } get { return id; } }

        public string Description
        { set { description = value; } get { return description; } }

        public string Type
        { set { type = value; } get { return type; } }

       /* protected List<string> list1 = new List<string>();
        public void selectitem()
        {
            list1.Add("1-Computer");
            list1.Add("2-Laptop");
            list1.Add("3-Printer");
        }*/

    }
}
