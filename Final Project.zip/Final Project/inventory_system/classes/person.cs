﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace inventory_system.classes
{
    class person
    {
        protected int id;
        protected string name;
        protected string address;
        protected int mobile;

        public int Id
        { set { id = value; } get { return id; } }
        public string Name
        { set { name = value; } get { return name; } }
        public string Address
        { set { address = value; } get { return address; } }
        public int Mobile
        { set { mobile = value; } get { return mobile; } }

        //Methods defining

       



    }
}
