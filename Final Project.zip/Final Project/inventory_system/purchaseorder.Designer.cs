﻿namespace inventory_system
{
    partial class purchaseorder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.searchpo = new System.Windows.Forms.Button();
            this.deletepo = new System.Windows.Forms.Button();
            this.textBoxpodescription = new System.Windows.Forms.TextBox();
            this.labelassettype = new System.Windows.Forms.Label();
            this.updatepo = new System.Windows.Forms.Button();
            this.textBoxpodate = new System.Windows.Forms.TextBox();
            this.labelassetname = new System.Windows.Forms.Label();
            this.textBoxponumber = new System.Windows.Forms.TextBox();
            this.labelAssetid = new System.Windows.Forms.Label();
            this.addpo = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // searchpo
            // 
            this.searchpo.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.searchpo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchpo.Location = new System.Drawing.Point(714, 408);
            this.searchpo.Name = "searchpo";
            this.searchpo.Size = new System.Drawing.Size(161, 37);
            this.searchpo.TabIndex = 45;
            this.searchpo.Text = "Search PO";
            this.searchpo.UseVisualStyleBackColor = false;
            // 
            // deletepo
            // 
            this.deletepo.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.deletepo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deletepo.Location = new System.Drawing.Point(511, 408);
            this.deletepo.Name = "deletepo";
            this.deletepo.Size = new System.Drawing.Size(161, 37);
            this.deletepo.TabIndex = 44;
            this.deletepo.Text = "Delete PO";
            this.deletepo.UseVisualStyleBackColor = false;
            // 
            // textBoxpodescription
            // 
            this.textBoxpodescription.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxpodescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxpodescription.Location = new System.Drawing.Point(315, 221);
            this.textBoxpodescription.Name = "textBoxpodescription";
            this.textBoxpodescription.Size = new System.Drawing.Size(198, 30);
            this.textBoxpodescription.TabIndex = 43;
            // 
            // labelassettype
            // 
            this.labelassettype.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.labelassettype.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelassettype.Location = new System.Drawing.Point(88, 184);
            this.labelassettype.Name = "labelassettype";
            this.labelassettype.Size = new System.Drawing.Size(184, 25);
            this.labelassettype.TabIndex = 42;
            this.labelassettype.Text = "PO Date";
            // 
            // updatepo
            // 
            this.updatepo.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.updatepo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updatepo.Location = new System.Drawing.Point(304, 408);
            this.updatepo.Name = "updatepo";
            this.updatepo.Size = new System.Drawing.Size(161, 37);
            this.updatepo.TabIndex = 41;
            this.updatepo.Text = "Update PO";
            this.updatepo.UseVisualStyleBackColor = false;
            // 
            // textBoxpodate
            // 
            this.textBoxpodate.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxpodate.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxpodate.Location = new System.Drawing.Point(315, 179);
            this.textBoxpodate.Name = "textBoxpodate";
            this.textBoxpodate.Size = new System.Drawing.Size(198, 30);
            this.textBoxpodate.TabIndex = 40;
            // 
            // labelassetname
            // 
            this.labelassetname.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.labelassetname.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelassetname.Location = new System.Drawing.Point(88, 226);
            this.labelassetname.Name = "labelassetname";
            this.labelassetname.Size = new System.Drawing.Size(184, 25);
            this.labelassetname.TabIndex = 39;
            this.labelassetname.Text = "PO Description";
            // 
            // textBoxponumber
            // 
            this.textBoxponumber.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxponumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxponumber.Location = new System.Drawing.Point(315, 130);
            this.textBoxponumber.Name = "textBoxponumber";
            this.textBoxponumber.Size = new System.Drawing.Size(198, 30);
            this.textBoxponumber.TabIndex = 38;
            // 
            // labelAssetid
            // 
            this.labelAssetid.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.labelAssetid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAssetid.Location = new System.Drawing.Point(88, 133);
            this.labelAssetid.Name = "labelAssetid";
            this.labelAssetid.Size = new System.Drawing.Size(184, 25);
            this.labelAssetid.TabIndex = 37;
            this.labelAssetid.Text = "PO Number";
            // 
            // addpo
            // 
            this.addpo.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.addpo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addpo.Location = new System.Drawing.Point(84, 408);
            this.addpo.Name = "addpo";
            this.addpo.Size = new System.Drawing.Size(161, 37);
            this.addpo.TabIndex = 36;
            this.addpo.Text = "Add PO";
            this.addpo.UseVisualStyleBackColor = false;
            // 
            // purchaseorder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(957, 502);
            this.Controls.Add(this.searchpo);
            this.Controls.Add(this.deletepo);
            this.Controls.Add(this.textBoxpodescription);
            this.Controls.Add(this.labelassettype);
            this.Controls.Add(this.updatepo);
            this.Controls.Add(this.textBoxpodate);
            this.Controls.Add(this.labelassetname);
            this.Controls.Add(this.textBoxponumber);
            this.Controls.Add(this.labelAssetid);
            this.Controls.Add(this.addpo);
            this.Name = "purchaseorder";
            this.Text = "purchaseorder";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button searchpo;
        private System.Windows.Forms.Button deletepo;
        private System.Windows.Forms.TextBox textBoxpodescription;
        private System.Windows.Forms.Label labelassettype;
        private System.Windows.Forms.Button updatepo;
        private System.Windows.Forms.TextBox textBoxpodate;
        private System.Windows.Forms.Label labelassetname;
        private System.Windows.Forms.TextBox textBoxponumber;
        private System.Windows.Forms.Label labelAssetid;
        private System.Windows.Forms.Button addpo;
    }
}