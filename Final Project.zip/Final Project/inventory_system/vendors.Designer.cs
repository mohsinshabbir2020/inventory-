﻿namespace inventory_system
{
    partial class vendors
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxvendorname = new System.Windows.Forms.TextBox();
            this.labeladminpassqord = new System.Windows.Forms.Label();
            this.textBoxvendorid = new System.Windows.Forms.TextBox();
            this.labelname = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxadress = new System.Windows.Forms.TextBox();
            this.textBoxcontactnumber = new System.Windows.Forms.TextBox();
            this.comboBoxitem = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBoxvendorname
            // 
            this.textBoxvendorname.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxvendorname.Location = new System.Drawing.Point(331, 133);
            this.textBoxvendorname.Name = "textBoxvendorname";
            this.textBoxvendorname.Size = new System.Drawing.Size(100, 30);
            this.textBoxvendorname.TabIndex = 10;
            // 
            // labeladminpassqord
            // 
            this.labeladminpassqord.AutoSize = true;
            this.labeladminpassqord.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeladminpassqord.Location = new System.Drawing.Point(171, 138);
            this.labeladminpassqord.Name = "labeladminpassqord";
            this.labeladminpassqord.Size = new System.Drawing.Size(133, 25);
            this.labeladminpassqord.TabIndex = 9;
            this.labeladminpassqord.Text = "Vendor Name";
            // 
            // textBoxvendorid
            // 
            this.textBoxvendorid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxvendorid.Location = new System.Drawing.Point(331, 82);
            this.textBoxvendorid.Name = "textBoxvendorid";
            this.textBoxvendorid.Size = new System.Drawing.Size(100, 30);
            this.textBoxvendorid.TabIndex = 8;
            // 
            // labelname
            // 
            this.labelname.AutoSize = true;
            this.labelname.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelname.Location = new System.Drawing.Point(171, 87);
            this.labelname.Name = "labelname";
            this.labelname.Size = new System.Drawing.Size(100, 25);
            this.labelname.TabIndex = 7;
            this.labelname.Text = "Vendor ID";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(165, 387);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(707, 37);
            this.button1.TabIndex = 6;
            this.button1.Text = "Add";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(171, 309);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 25);
            this.label1.TabIndex = 12;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(171, 251);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(154, 25);
            this.label2.TabIndex = 13;
            this.label2.Text = "Contact Number";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(171, 197);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 25);
            this.label3.TabIndex = 14;
            this.label3.Text = "Adress";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // textBoxadress
            // 
            this.textBoxadress.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxadress.Location = new System.Drawing.Point(331, 194);
            this.textBoxadress.Name = "textBoxadress";
            this.textBoxadress.Size = new System.Drawing.Size(100, 30);
            this.textBoxadress.TabIndex = 15;
            // 
            // textBoxcontactnumber
            // 
            this.textBoxcontactnumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxcontactnumber.Location = new System.Drawing.Point(331, 251);
            this.textBoxcontactnumber.Name = "textBoxcontactnumber";
            this.textBoxcontactnumber.Size = new System.Drawing.Size(100, 30);
            this.textBoxcontactnumber.TabIndex = 16;
            // 
            // comboBoxitem
            // 
            this.comboBoxitem.FormattingEnabled = true;
            this.comboBoxitem.Location = new System.Drawing.Point(331, 309);
            this.comboBoxitem.Name = "comboBoxitem";
            this.comboBoxitem.Size = new System.Drawing.Size(121, 21);
            this.comboBoxitem.TabIndex = 17;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(171, 305);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 25);
            this.label4.TabIndex = 18;
            this.label4.Text = "Items";
            // 
            // vendors
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(964, 500);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.comboBoxitem);
            this.Controls.Add(this.textBoxcontactnumber);
            this.Controls.Add(this.textBoxadress);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxvendorname);
            this.Controls.Add(this.labeladminpassqord);
            this.Controls.Add(this.textBoxvendorid);
            this.Controls.Add(this.labelname);
            this.Controls.Add(this.button1);
            this.Name = "vendors";
            this.Text = "Vendors";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxvendorname;
        private System.Windows.Forms.Label labeladminpassqord;
        private System.Windows.Forms.TextBox textBoxvendorid;
        private System.Windows.Forms.Label labelname;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxadress;
        private System.Windows.Forms.TextBox textBoxcontactnumber;
        private System.Windows.Forms.ComboBox comboBoxitem;
        private System.Windows.Forms.Label label4;
    }
}